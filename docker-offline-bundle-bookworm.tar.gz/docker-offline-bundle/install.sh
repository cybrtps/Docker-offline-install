#!/bin/bash

set -e

echo "🔧 Installing Docker Engine components..."
sudo dpkg -i containerd.io_*.deb docker-ce-cli_*.deb docker-ce_*.deb

echo "🐳 Installing Docker Compose binary..."
sudo mv docker-compose /usr/local/bin/docker-compose
sudo chmod +x /usr/local/bin/docker-compose

echo "🚀 Enabling and starting Docker service..."
sudo systemctl enable docker
sudo systemctl start docker

echo "✅ Docker installation complete."
docker --version
docker compose version || docker-compose version